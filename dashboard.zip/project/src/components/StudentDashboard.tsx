import React from 'react';
import { 
  Calendar, 
  Clock, 
  TrendingUp, 
  Bell, 
  BookOpen, 
  Award, 
  Play,
  CheckCircle,
  AlertCircle,
  User
} from 'lucide-react';

interface StudentDashboardProps {
  user: {
    name: string;
    email: string;
    profileImg?: string;
  };
}

const StudentDashboard: React.FC<StudentDashboardProps> = ({ user }) => {
  // Mock data - in real app, this would come from API
  const upcomingExams = [
    {
      id: 1,
      title: 'Mathematics Final Exam',
      date: '2025-01-20',
      time: '10:00 AM',
      duration: '2 hours',
      totalMarks: 100,
      registeredStudents: 45
    },
    {
      id: 2,
      title: 'Physics Quiz',
      date: '2025-01-22',
      time: '2:00 PM',
      duration: '1 hour',
      totalMarks: 50,
      registeredStudents: 32
    },
    {
      id: 3,
      title: 'Chemistry Lab Test',
      date: '2025-01-25',
      time: '11:00 AM',
      duration: '1.5 hours',
      totalMarks: 75,
      registeredStudents: 28
    }
  ];

  const recentResults = [
    {
      id: 1,
      examTitle: 'English Literature',
      score: 85,
      totalMarks: 100,
      date: '2025-01-15',
      grade: 'A'
    },
    {
      id: 2,
      examTitle: 'Biology Test',
      score: 78,
      totalMarks: 100,
      date: '2025-01-12',
      grade: 'B+'
    },
    {
      id: 3,
      examTitle: 'History Quiz',
      score: 92,
      totalMarks: 100,
      date: '2025-01-10',
      grade: 'A+'
    }
  ];

  const notifications = [
    {
      id: 1,
      message: 'New exam "Advanced Calculus" has been scheduled',
      type: 'info',
      time: '2 hours ago',
      isRead: false
    },
    {
      id: 2,
      message: 'Results for Physics Quiz are now available',
      type: 'success',
      time: '1 day ago',
      isRead: false
    },
    {
      id: 3,
      message: 'Reminder: Mathematics exam starts in 2 days',
      type: 'warning',
      time: '2 days ago',
      isRead: true
    }
  ];

  const stats = {
    totalExams: 12,
    completedExams: 8,
    averageScore: 84.5,
    upcomingExams: 4
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-[#333446] rounded-full flex items-center justify-center">
                <User className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Welcome back, {user.name}</h1>
                <p className="text-gray-600">Ready to ace your next exam?</p>
              </div>
            </div>
            <div className="relative">
              <button className="p-2 text-gray-600 hover:text-[#333446] transition-colors">
                <Bell className="w-6 h-6" />
                <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Exams</p>
                <p className="text-3xl font-bold text-gray-900">{stats.totalExams}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Completed</p>
                <p className="text-3xl font-bold text-gray-900">{stats.completedExams}</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Average Score</p>
                <p className="text-3xl font-bold text-gray-900">{stats.averageScore}%</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Upcoming</p>
                <p className="text-3xl font-bold text-gray-900">{stats.upcomingExams}</p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                <Clock className="w-6 h-6 text-orange-600" />
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Upcoming Exams */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-semibold text-gray-900">Upcoming Exams</h2>
                  <Calendar className="w-5 h-5 text-gray-500" />
                </div>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  {upcomingExams.map((exam) => (
                    <div key={exam.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900">{exam.title}</h3>
                        <div className="flex items-center space-x-4 mt-2 text-sm text-gray-600">
                          <span className="flex items-center">
                            <Calendar className="w-4 h-4 mr-1" />
                            {exam.date}
                          </span>
                          <span className="flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            {exam.time}
                          </span>
                          <span className="flex items-center">
                            <Award className="w-4 h-4 mr-1" />
                            {exam.totalMarks} marks
                          </span>
                        </div>
                      </div>
                      <button className="bg-[#333446] text-white px-4 py-2 rounded-lg hover:bg-[#2a2d3e] transition-colors flex items-center space-x-2">
                        <Play className="w-4 h-4" />
                        <span>Start</span>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Notifications */}
          <div>
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-6">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-lg font-semibold text-gray-900">Notifications</h2>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  {notifications.slice(0, 3).map((notification) => (
                    <div key={notification.id} className={`p-3 rounded-lg border-l-4 ${
                      notification.type === 'info' ? 'bg-blue-50 border-blue-400' :
                      notification.type === 'success' ? 'bg-green-50 border-green-400' :
                      'bg-yellow-50 border-yellow-400'
                    } ${!notification.isRead ? 'ring-2 ring-blue-100' : ''}`}>
                      <div className="flex items-start space-x-3">
                        <div className={`w-2 h-2 rounded-full mt-2 ${
                          notification.type === 'info' ? 'bg-blue-400' :
                          notification.type === 'success' ? 'bg-green-400' :
                          'bg-yellow-400'
                        }`}></div>
                        <div className="flex-1">
                          <p className="text-sm text-gray-800">{notification.message}</p>
                          <p className="text-xs text-gray-500 mt-1">{notification.time}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <button className="w-full mt-4 text-sm text-[#333446] hover:text-[#2a2d3e] font-medium">
                  View all notifications
                </button>
              </div>
            </div>

            {/* Recent Results */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-lg font-semibold text-gray-900">Recent Results</h2>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  {recentResults.slice(0, 3).map((result) => (
                    <div key={result.id} className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium text-gray-900">{result.examTitle}</h3>
                        <p className="text-sm text-gray-600">{result.date}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-lg text-gray-900">{result.score}/{result.totalMarks}</p>
                        <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${
                          result.grade.startsWith('A') ? 'bg-green-100 text-green-800' :
                          result.grade.startsWith('B') ? 'bg-blue-100 text-blue-800' :
                          'bg-yellow-100 text-yellow-800'
                        }`}>
                          {result.grade}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
                <button className="w-full mt-4 text-sm text-[#333446] hover:text-[#2a2d3e] font-medium">
                  View all results
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;