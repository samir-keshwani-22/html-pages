import React, { useState } from 'react';
import StudentDashboard from './components/StudentDashboard';
import AdminDashboard from './components/AdminDashboard';
import { Users, Settings } from 'lucide-react';

function App() {
  const [activeRole, setActiveRole] = useState<'student' | 'admin'>('student');

  // Mock user data
  const mockUser = {
    name: 'John Doe',
    email: 'john@example.com',
    profileImg: undefined
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Role Switcher - This would be removed in production */}
      <div className="bg-[#333446] text-white p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-white bg-opacity-20 rounded-lg flex items-center justify-center">
              <Settings className="w-5 h-5" />
            </div>
            <span className="font-semibold">Exam Portal</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-300">View as:</span>
            <button
              onClick={() => setActiveRole('student')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center space-x-2 ${
                activeRole === 'student'
                  ? 'bg-white text-[#333446]'
                  : 'bg-white bg-opacity-20 text-white hover:bg-opacity-30'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Student</span>
            </button>
            <button
              onClick={() => setActiveRole('admin')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center space-x-2 ${
                activeRole === 'admin'
                  ? 'bg-white text-[#333446]'
                  : 'bg-white bg-opacity-20 text-white hover:bg-opacity-30'
              }`}
            >
              <Settings className="w-4 h-4" />
              <span>Admin</span>
            </button>
          </div>
        </div>
      </div>

      {/* Dashboard Content */}
      {activeRole === 'student' ? (
        <StudentDashboard user={mockUser} />
      ) : (
        <AdminDashboard user={mockUser} />
      )}
    </div>
  );
}

export default App;